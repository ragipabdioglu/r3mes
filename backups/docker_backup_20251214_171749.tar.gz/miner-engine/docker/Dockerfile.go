# R3MES Blockchain Node - Go Dockerfile
# Cosmos SDK v0.50.x, CometBFT v0.38.27, Go 1.22

FROM golang:1.22-alpine AS builder

# Install build dependencies
RUN apk add --no-cache \
    git \
    make \
    bash \
    ca-certificates \
    tzdata

# Set working directory
WORKDIR /build

# Copy go mod files
COPY remes/go.mod remes/go.sum ./

# Download dependencies
RUN go mod download

# Copy source code
COPY remes/ ./

# Build remesd binary
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build \
    -mod=readonly \
    -tags 'netgo,ledger,musl,static_build' \
    -ldflags '-extldflags "-static" -w -s -X github.com/cosmos/cosmos-sdk/version.Name=remes -X github.com/cosmos/cosmos-sdk/version.AppName=remesd' \
    -o /build/remesd \
    ./cmd/remesd

# Final stage
FROM alpine:latest

# Install runtime dependencies
RUN apk add --no-cache \
    ca-certificates \
    tzdata \
    curl \
    bash

# Copy binary from builder
COPY --from=builder /build/remesd /usr/local/bin/remesd

# Create app directory
WORKDIR /app

# Create entrypoint script
RUN echo '#!/bin/sh\n\
set -e\n\
exec remesd "$@"\n\
' > /app/entrypoint.sh && chmod +x /app/entrypoint.sh

ENTRYPOINT ["/app/entrypoint.sh"]

# Default command
CMD ["version"]

